<?php
/* Plugin Name: Referans Ekleme Eklentisi2
Theme URI: referansplugin
Author: Kubilay Sevük
Author URI: d-help.com
Description: D-Help kurumsal referans ekleme eklentisi.
Version: 1.0 */
?>
<?php
function menu_ekle1(){
    add_menu_page('Hosgeldiniz1','Referans Ekle','manage_options','edit.php?post_type=ebultenabonesi','','',80);
}
add_action('admin_menu','menu_ekle1');

//Klasik Editör
// add_filter('use_block_editor_for_post', '__return_false', 10);


//İçerik Tipi
function iceriktipleri() {
	$labels = array(
		'name'                => __( 'Referanslar' ),
		'singular_name'       => __( 'Referanslar' ),
		'menu_name'           => __( 'Referanslar' ),
		'parent_item_colon'   => __( 'Referanslar' ),
		'all_items'           => __( 'Tüm Referanslar' ),
		'view_item'           => __( 'Referans Gör' ),
		'add_new_item'        => __( 'Yeni Referans Ekle' ),
		'add_new'             => __( 'Yeni Referans Ekle' ),
		'edit_item'           => __( 'Referans Düzenle' ),
		'update_item'         => __( 'Referans Güncelle' ),
		'search_items'        => __( 'Referans Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	$args = array(
		'label'               => __( 'ebultenabonesi' ),
		'description'         => __( 'Aboneler' ),
		'labels'              => $labels,
		
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => false,
		'show_in_rest' 		  => true,
		'rest_base'          => 'ebultenabonesi',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 3,
		"menu_icon" => "dashicons-email-alt",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
		'supports' => array('title','thumbnail','category'),
	);	
	register_post_type( 'ebultenabonesi', $args );
}

add_action( 'init', 'iceriktipleri', 0 );

//metaboxlar
function meta_boxlar(){

//Referans Bilgileri
add_meta_box(
	'abone_bilgileri_id',
	'Referans Bilgileri',
	'abone_bilgileri',
	'ebultenabonesi'
);
}
add_action('add_meta_boxes','meta_boxlar')
?>
<?php
function abone_bilgileri($post){
add_theme_support('post-thumbnails');
}
//Referans plugin widget
function referans_bileseni_yukle() {
    register_widget('referans_bileseni');
}
add_action('widgets_init','referans_bileseni_yukle');

class referans_bileseni extends WP_Widget {
    function __construct() {
        parent::__construct(
        'referans_bileseni',__('Referans Bileşeni'),
        array ('description' => __('Referans Ekleme Bileşeni'))   
        );
    }
function widget($args,$instance) {

    $bilesen_baslik2 = apply_filters('widget_title',$instance['title']);
    echo $args ['before_widget'];
    ?>
    <section class="brand-client section-margin">
                <div class="container">
                <?php $query = new WP_Query(array(
                'post_type' => 'ebultenabonesi',
                'post_status' => 'publish',
                'order_by' => 'ID',
                'order' => 'DESC',
                ));
                while($query->have_posts()){
                $query->the_post();
                $post_id = get_the_ID(); ?> 
                <table style="display:inline;">
                <tr>    
                <td><img src="<?php echo wp_get_attachment_image_src(get_post_thumbnail_id())[0]; ?>" 
                width='120'; height='120';></td>
                </tr>
                <tr>
                <td><p><?php the_title(); ?></p></td>
                </tr>
                <a href=""></a>
                </table>
                <?php } wp_reset_query(); ?>
                </div>
</section>
<?php
echo $args['after_widget'];
}
function form($instance) {
    if( isset($instance ['title'] ) ) {
        $bilesen_baslik2 = $instance['title'];
    }
    else {
        $bilesen_baslik2 = __('Referans Bileşeni');
    } ?>
    <p>
<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>"
type="text" value="<?php echo esc_attr($bilesen_baslik2); ?> " />
</p>
<?php } 
function update($new_instance, $old_instance) {
    $instance =array();
    $instance['title']= (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
    return $instance;
}
}
?>