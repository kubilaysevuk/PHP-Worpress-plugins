<?php
/* Plugin Name: İnstagram Feed Ekleme Eklentisi
Theme URI: instagram plugin
Author: Kubilay Sevük
Author URI: d-help.com
Description: D-Help instagram feed ekleme eklentisi.
Version: 1.0 */  
add_action('admin_menu','menu_eklemesi');
function menu_eklemesi(){
    add_menu_page('','İnstagram Plugin','manage_options','instagram-plugin/send.php','','dashicons-instagram');
}
//instagram api...
function instagram_bileseni_yukle() {
    register_widget('instagram_bileseni');
}
add_action('widgets_init','instagram_bileseni_yukle');

class instagram_bileseni extends WP_Widget {
    function __construct() {
        parent::__construct(
        'instagram_bileseni',__('İnstagram Bileşeni'),
        array ('description' => __('İnstagram Feed Bileşeni'))   
        );
    }
    
function widget($args,$instance) {

    $feed_baslik = apply_filters('widget_title',$instance['title']);
    echo $args ['before_widget'];
    ?>
    <section class="brand-client section-margin">
        <div class="container">
        <table style="display:inline;">
        <tr>    
        <td><iframe  width="400" height="260"
                src="<?php echo get_option('feed-link'); ?>"></td>
        </tr>
        <tr>
        <td><p></p></td>
        </tr>
        <a href=""></a>
        </table>
        </div>
</section>
<?php
echo $args['after_widget'];
}

function form($instance) {
    if( isset($instance ['title'] ) ) {
        $feed_baslik = $instance['title'];
    }
    else {
        $feed_baslik = __('İnstagram Feed');
    }
    ?>
<p>
<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>"
type="text" value="<?php echo esc_attr($feed_baslik); ?> " />
</p>
<?php
}

function update($new_instance, $old_instance) {
    $instance =array();
    $instance['title']= (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
    return $instance;
}
}
?>