<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İnstagram Feed Plugin</title>
</head>
<body>
<form method="post"
      action="options.php">
      <?php settings_fields ('feed_plugini'); ?>
      <?php do_settings_sections('feed_plugini'); ?>
    <!-- Video Ekleme Formu -->
    <table class="form-table" >
        <tr>
            <th scope="row">
                <label for="blogname">Başlık</label>
            </th>
            <td>
            <input type="text" value="<?php echo get_option('feed-baslik'); ?>" placeholder="Başlığı Giriniz" name="feed-baslik">
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="blogname" >Link</label>
            </th>
            <td>
            <input type="text" value="<?php echo get_option('feed-link'); ?>" placeholder="instagram linki" name="feed-link">
            </td>
        </tr>
    </table>
<?php submit_button(); ?>
</form>
</body>
</html>