<?php
/* Plugin Name: Kurucu Üyeler Ayarlar
Theme URI: kurucu-uyeler
Author: Kubilay Sevük
Author URI: https://www.linkedin.com/in/kubilay-sev%C3%BCk-5a68a4175/
Description: Kurucu Üyeler sayfası için düzenleme yapabilen wordpress eklentisi.
Version: 1.0.0 */
?>
<?php
add_action( 'init', 'create_kurucu_posttype' );
function create_kurucu_posttype() {
    $args = array(
      'public' => false,
      'show_ui' => true,
      'menu_icon' => 'dashicons-admin-post',
      'capability_type' => 'page',
      'rewrite' => array( 'kurucu-loc', 'post_tag' ),
      'label'  => 'Kurucu Üyeler Yönetimi',
      'supports' => array( 'title', 'editor', 'custom-fields', 'thumbnail', 'page-attributes'),
      'taxonomies' => array('category')
    );
    register_post_type( 'kurucu', $args );
}

//metaboxlar
function kurucu_metaboxlar(){

    //Referans Bilgileri
    add_meta_box(
        'kisi_bilgileri_id',
        'Kisi Bilgileri',
        'kurucu_kisi_bilgileri',
        'kurucu'
    );
    }
    add_action('add_meta_boxes','kurucu_metaboxlar');
    function kurucu_kisi_bilgileri(){
        global $post;
        ?>
<div class="row">
    <div class="label">Makam Bilgisi</div>
    <div class="fields">
        <input type="text" name="_diwp_reading_time" value="<?php echo get_post_meta($post->ID, 'kurucu_makam', true)?>"/>
    </div>
    <div class="label">Mail Bilgisi</div>
    <div class="fields">
        <input type="text" name="_diwp_reading_time2" value="<?php echo get_post_meta($post->ID, 'kurucu_mail', true)?>"/>
    </div>
</div>
<?php
    }
    function kurucu_save_custom_metabox(){
 
        global $post;
     
        if(isset($_POST["_diwp_reading_time"])):
             
            update_post_meta($post->ID, 'kurucu_makam', $_POST["_diwp_reading_time"]);
         
        endif;
        if(isset($_POST["_diwp_reading_time2"])):
             
            update_post_meta($post->ID, 'kurucu_mail', $_POST["_diwp_reading_time2"]);
         
        endif;
    }
     
    add_action('save_post', 'kurucu_save_custom_metabox');

//END kurucu