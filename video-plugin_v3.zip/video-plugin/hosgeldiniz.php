<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Plugin</title>
</head>
<h1>Video Ekleme Eklentisi</h1><br>
<body>

<form method="post"
      action="options.php">
      <?php settings_fields ('yaziekleme_plugini'); ?>
      <?php do_settings_sections('yaziekleme_plugini'); ?>
    <!-- Video Ekleme Formu -->
    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="blogname">Başlık</label>
            </th>
        
            <td>
            <input type="text" value="<?php echo get_option('ye-baslik'); ?>" placeholder="Başlığı Giriniz" name="ye-baslik">
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="blogname" >Link</label>
            </th>
            <td>
            <input type="text" value="<?php echo get_option('ye-link'); ?>" placeholder="https://youtu.be/Lwf-E4Q" name="ye-link">
            </td>
            
        </tr>
    </table>
<?php submit_button(); ?>
</form>
    <!-- End Video Ekleme Formu -->

    <!-- Video Gösterme Formu -->
    
<table class="form-table">

            <div>
                <iframe width="320" height="260"
                src="<?php echo $replace; ?>">
                </iframe>
            </div>
    <?php  ?>
    <!-- End Video Gösterme Formu -->
<?php 
add_shortcode('video_formu','video_eklentisi_shortcode');
?>
</body>
</html>