<?php
/* Plugin Name: Video Ekleme Eklentisi
Theme URI: videoplugin
Author: Kubilay Sevük
Author URI: d-help.com
Description: D-Help kurumsal video ekleme eklentisi.
Version: 1.0 */  
@error_reporting(E_ALL & ~E_NOTICE);
@ini_set('error_reporting', E_ALL & ~E_NOTICE);
add_action('admin_menu','menu_ekleme');
function menu_ekleme(){
    add_menu_page('','Video Plugin','manage_options','video-plugin/hosgeldiniz.php','','dashicons-format-video');
    add_submenu_page('video-plugin/hosgeldiniz.php','','Bütün Videolar','manage_options','edit.php?post_type=videogirisi','');
    add_submenu_page('video-plugin/hosgeldiniz.php','','Video Ekle','manage_options','post-new.php?post_type=videogirisi','');
    add_submenu_page('video-plugin/hosgeldiniz.php','','Video Kategorileri','manage_options','edit-tags.php?taxonomy=videolar_kategori&post_type=videogirisi','');
}
//create video shortcode
add_shortcode('video_short', 'testimonial_query');

function testimonial_query($atts, $content){
    extract(shortcode_atts(array( // a few default values
    'id' => null,
    'posts_per_page' => '1',
    'caller_get_posts' => 1)
    , $atts));

    $args = array(
    'post_type' => 'videogirisi',
    'numberposts' => -1
    );

    if($atts['id']){
     $args['p'] = $atts['id'];
    }
    global $post;
    $posts = new WP_Query($args);
    $out = '';

    if ($posts->have_posts())
        while ($posts->have_posts()):
            $posts->the_post();
            //$url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
            $out = $out .'<h2>' .the_title() . '</h2>';
            $out = $out .'<p>'.the_content().'<p>';
        endwhile;
    else
    return; // no posts found
    wp_reset_query();
    return html_entity_decode($out);
}

//Videolar posstype oluşturma 
add_action('init','videolar_posttype');
function videolar_posttype(){
    $labels = array(
        'name' => _x('Videolar','Videolar'),
        'singular_name' => _x('Video','Videoo'),
        'manu_name' => _x('Videolar','Videolar'),
        'name_admin_bar' => _x('Videolar','videolar'),
        'add_new' => _x('Video Ekle','Video ekle'),
        'add_new_item' => __('Yeni Video Ekle'),
        'new_item' => __('Yeni Video'),
        'edit_item' => __('Video Düzenle'),
        'view_item' => __('Video Görüntüleme'),
        'all_items' => __('Bütün Videolar'),
        'search_items' => __('Video Ara'),
        'not_found' => __('Video Yorumu Bulunamadı'),
        'not_found_in_trash' => __('Video Yorumu Çöp Kutusunda Bulunamadı'),
    );

    $args = array(
        'label'               => __( 'videogirisi' ),
        'labels'=> $labels,
        'description' => __('Videolar Post Type'),
        'public' => true,
        'publicly_archive' =>true,
        'publicly_querable' =>true,
        'show_ui' =>true,
        'show_in_menu' =>false,
        'query_var' =>true,
        'rewrite' =>array(
            'slug' =>'videogirisi',
            'with_front' =>true,
            'hierarchical' =>true,
            'query_var' =>true,
        ),
        'capability_type' =>'post',
        'hierarchical' =>true,
        'show_in_nav_menus' =>true,
        'menu_position' =>5,
        'menu_icon' =>'dashicons-format-video',
        'supports' => array('title','editor','thumbnail','revisions','category','media','permalink'),
    );
    register_taxonomy('videolar_kategori','videogirisi',array(
        'hierarchical' =>true,
        'label' => __('Video Kategorileri'),
        'singular_name' => __('Video Kategorisi'),
        "rewrite" => array( "slug" => "city/%city_name%", "with_front" => true ),
        'query_var' =>true,
    ));

    register_post_type( 'videogirisi', $args );
    add_action( 'init', 'videolar_posttype', 0 );
    }
    function update_edit_form(){
        echo'enctype"multipart/form-data"';
    }
    add_action('post_edit_form_tag','update_edit_form');
    
//insert post id in custom post type
    function add_column( $columns ){
        $columns['post_id_clmn'] = 'ID'; // $columns['Column ID'] = 'Column Title';
        return $columns;
    }
    add_filter('manage_posts_columns', 'add_column', 5);
    
    function column_content( $column, $id ){
        if( $column === 'post_id_clmn')
            echo $id;
    }
    add_action('manage_posts_custom_column', 'column_content', 5, 2);

//Video plugin widget
function video_bileseni_yukle() {
    register_widget('video_bileseni');
}
add_action('widgets_init','video_bileseni_yukle');

class video_bileseni extends WP_Widget {
    function __construct() {
        parent::__construct(
        'video_bileseni',__('Video Bileşeni'),
        array ('description' => __('Video Youtube Bileşeni'))   
        );
    }
    
function widget($args,$instance) {

    $eski = "youtu.be/"; 
    $yeni = "youtube.com/embed/";
    $metin = get_option('ye-link');
    $replace = str_replace($eski, $yeni, $metin);
    $bilesen_baslik = apply_filters('widget_title',$instance['title']);

    echo $args ['before_widget'];
    ?>
    <div>
    <table style="display:inline;">
                <tr>    
                <td><?php echo get_option('ye-baslik'); ?></td>
                </tr>
                <tr>
                <td><iframe  width="400" height="260"
                src="<?php echo $replace; ?>">
                </iframe></td>
                </tr>
</table>
</div>
    <?php 
    echo $args['after_widget'];
}

function form($instance) {
    if( isset($instance ['title'] ) ) {
        $bilesen_baslik = $instance['title'];
    }
    else {
        $bilesen_baslik = __('Video Bileşeni');
    }
    ?>
<p>
<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>"
type="text" value="<?php echo esc_attr($bilesen_baslik); ?> " />
</p>
<?php
}
function update($new_instance, $old_instance) {
    $instance =array();
    $instance['title']= (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
    return $instance;
}
}
?>
