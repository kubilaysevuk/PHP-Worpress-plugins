<?php
/* Plugin Name: Merkez Disiplin Kurulu Ayarlar
Theme URI: mdkyonetimi
Author: Kubilay Sevük
Author URI: https://www.linkedin.com/in/kubilay-sev%C3%BCk-5a68a4175/
Description: Merkez Disiplin Kurulu sayfası için düzenleme yapabilen wordpress eklentisi.
Version: 1.0.0 */
?>
<?php
add_action( 'init', 'create_mdk_posttype' );
function create_mdk_posttype() {
    $args = array(
      'public' => false,
      'show_ui' => true,
      'menu_icon' => 'dashicons-admin-post',
      'capability_type' => 'page',
      'rewrite' => array( 'mdk-loc', 'post_tag' ),
      'label'  => 'MDK Yönetimi',
      'supports' => array( 'title', 'editor', 'custom-fields', 'thumbnail', 'page-attributes'),
      'taxonomies' => array('category')
    );
    register_post_type( 'mdk', $args );
}

//metaboxlar
function mdk_metaboxlar(){

    //Referans Bilgileri
    add_meta_box(
        'kisi_bilgileri_id',
        'Kisi Bilgileri',
        'mdk_kisi_bilgileri',
        'mdk'
    );
    }
    add_action('add_meta_boxes','mdk_metaboxlar');
    function mdk_kisi_bilgileri(){
        global $post;
        ?>
<div class="row">
    <div class="label">Makam Bilgisi</div>
    <div class="fields">
        <input type="text" name="_diwp_reading_time" value="<?php echo get_post_meta($post->ID, 'mdk_makam', true)?>"/>
    </div>
    <div class="label">Mail Bilgisi</div>
    <div class="fields">
        <input type="text" name="_diwp_reading_time2" value="<?php echo get_post_meta($post->ID, 'mdk_mail', true)?>"/>
    </div>
</div>
<?php
    }
    function mdk_save_custom_metabox(){
 
        global $post;
     
        if(isset($_POST["_diwp_reading_time"])):
             
            update_post_meta($post->ID, 'mdk_makam', $_POST["_diwp_reading_time"]);
         
        endif;
        if(isset($_POST["_diwp_reading_time2"])):
             
            update_post_meta($post->ID, 'mdk_mail', $_POST["_diwp_reading_time2"]);
         
        endif;
    }
     
    add_action('save_post', 'mdk_save_custom_metabox');

//END MDK