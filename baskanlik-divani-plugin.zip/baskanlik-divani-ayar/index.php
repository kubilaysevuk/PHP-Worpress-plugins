<?php
/* Plugin Name: Başkanlık Divanı Ayarlar
Theme URI: baskanlikdivani
Author: Kubilay Sevük
Author URI: https://www.linkedin.com/in/kubilay-sev%C3%BCk-5a68a4175/
Description: Başkanlık divanı sayfası için düzenleme yapabilen wordpress eklentisi.
Version: 1.0.0 */
?>
<?php
add_action('admin_menu','menu_eklemesi1');
function menu_eklemesi1(){
    add_menu_page('','Başkanlık Divanı','manage_options','/edit.php?post_type=baskanlik-divani','','dashicons-admin-post');
    add_submenu_page('/edit.php?post_type=baskanlik-divani','','Yeni Ekle','manage_options','/post-new.php?post_type=baskanlik-divani','');
    add_submenu_page('/edit.php?post_type=baskanlik-divani','','Kategoriler','manage_options','/edit-tags.php?taxonomy=category&post_type=baskanlik-divani','');
}
//ZAFER BAŞKANLIK DİVANI
function dhelp_lite_register_post_type_baskanlik_divani() {
    $supports = array(
    'title', // post title
    'editor', // post content
    'author', // post author
    'thumbnail', // featured images
    'custom-fields', // custom fields
    'revisions', // post revisions
    'post-formats', // post formats
);

    $labels = array(
     'name' => __( 'Başkanlık Divanı', 'dhelp-lite' ),
     'singular_name' => __( 'Başkanlık Divanı', 'dhelp-lite' ),
     'add_new' => __( 'Yeni Kişi', 'dhelp-lite' ),
     'add_new_item' => __( 'Yeni Kişi Ekle', 'dhelp-lite' ),
     'edit_item' => __( 'Kişi Düzenle', 'dhelp-lite' ),
     'new_item' => __( 'Yeni Kişi', 'dhelp-lite' ),
     'view_item' => __( 'Kişi Görüntüle', 'dhelp-lite'),
     'search_items' => __( 'Kişi Ara', 'dhelp-lite' ),
     'not_found' =>  __( 'Kişi Bulunamadı', 'dhelp-lite' ),
     'not_found_in_trash' => __( 'Çöp içinde Kişi bulunamadı', 'dhelp-lite' ),
 );

    $args = array(
       'labels' => $labels,
       'public' => true,
       'hierarchical' => false,
       'supports' => $supports,
       'taxonomies' => array('category'),
       'show_in_rest' => true,
       'exclude_from_search' => false,
       'show_in_menu' => false,
   );
    register_post_type( 'baskanlik-divani', $args );
}
add_action( 'init', 'dhelp_lite_register_post_type_baskanlik_divani' );
//metaboxlar
function metaboxlar(){

    //Referans Bilgileri
    add_meta_box(
        'kisi_bilgileri_id',
        'Kisi Bilgileri',
        'kisi_bilgileri',
        'baskanlik-divani'
    );
    }
    add_action('add_meta_boxes','metaboxlar');
    function kisi_bilgileri(){
        global $post;
        ?>
<div class="row">
    <div class="label">Makam Bilgisi</div>
    <div class="fields">
        <input type="text" name="_diwp_reading_time" value="<?php echo get_post_meta($post->ID, 'post_reading_time', true)?>"/>
    </div>
</div>
<?php
    }
    function diwp_save_custom_metabox(){
 
        global $post;
     
        if(isset($_POST["_diwp_reading_time"])):
             
            update_post_meta($post->ID, 'post_reading_time', $_POST["_diwp_reading_time"]);
         
        endif;
    }
     
    add_action('save_post', 'diwp_save_custom_metabox');

//END ZAFER BAŞKANLIK DİVANI