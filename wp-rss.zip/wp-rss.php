<?php
$html = "";
// URL containing rss feed
$url = "https://zaferpartisi.org.tr/haberler/feed/";
$xml = simplexml_load_file($url);
$html .= "<div class='rss-block' 
style='display: grid;
grid-template-columns: repeat(2,1fr);
gap: 35px;
padding: 130px;'>";
for($i = 0; $i < 10; $i++){
  
    $foto = $xml->channel->image->url;
	$title = $xml->channel->item[$i]->title;
	$link = $xml->channel->item[$i]->link;
	$description = $xml->channel->item[$i]->description;
	$pubDate = $xml->channel->item[$i]->pubDate;
    
    $html .= "<div class='block' style='width: 75%; margin: 5px px 5px 35px 5px;
    padding: 10px; border-radius: 25px; box-shadow: 0 0 10px 0px #adadad; /* display: none; */ margin: 0; padding: 0; box-sizing: border-box;'>";
    $html .= '<div class="imgtext"><a href="'.$link.'"><img style="width: 50%; height: 50%; max-height: 330px;" src="https://zaferpartisi.org.tr/wp-content/uploads/2023/02/zafer1.png"><br></div>'; 
	$html .= "<a target='_blank' href='$link'><h2>$title</h2></a>"; // Title of post
	$html .= "$description"; // Description
	$html .= "<br />$pubDate<br /><br />"; // Date Published
    $html .= "</div>";
}
$html .= "</div>";
echo "$html<br />";